﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPIUserReg.Models;

namespace WebAPIUserReg.Controllers
{
    public class EmpGrudController : ApiController
    {
        EmployeeDBEntities nd = new EmployeeDBEntities();
        public IHttpActionResult getemp()
        {            
            var results = nd.Employees.ToList();
            return Ok(results);
        }

        [HttpPost]
        public IHttpActionResult empinsert(Employee empinsert)
        {
            nd.Employees.Add(empinsert);
            nd.SaveChanges();
            return Ok();
        }

        public IHttpActionResult GetEmpid(int id)
        {
            EmpClass empdeitals = null;
            empdeitals = nd.Employees.Where(x => x.ID == id).Select(x => new EmpClass()
                {
                    ID = x.ID,
                    Name = x.Name,
                    Pwd = x.Pwd,
                    Repwd = x.Repwd,
                    Email = x.Email,
                    Gender = x.Gender,
                    joindate = (DateTime)x.Joindate,
                    Role = (int)x.Role,
                }).FirstOrDefault<EmpClass>();
            if(empdeitals==null)
            {
                return NotFound();
            }

            return Ok(empdeitals);
        }

        public IHttpActionResult Put(EmpClass ec)
        {
            var updateemp=nd.Employees.Where(x=>x.ID == ec.ID).FirstOrDefault<Employee>();
            if(updateemp!=null)
            {
                updateemp.ID = ec.ID;
                updateemp.Name = ec.Name;
                updateemp.Pwd = ec.Pwd;
                updateemp.Repwd = ec.Repwd;
                updateemp.Email = ec.Email;
                updateemp.Gender = ec.Gender;
                updateemp.Joindate = ec.joindate;
                updateemp.Role = (int)ec.Role;
                nd.SaveChanges();
            }
            else
            {
                return NotFound();
            }
            return Ok();
        }

        public IHttpActionResult Delete(int id)
        {
            var empdel = nd.Employees.Where(x => x.ID == id).FirstOrDefault();
            nd.Entry(empdel).State = System.Data.Entity.EntityState.Deleted;
            nd.SaveChanges();
            return Ok();
        }


       
    }
}
