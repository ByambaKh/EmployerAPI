﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebAPIUserReg.Models;
using System.Net.Http;

namespace WebAPIUserReg.Controllers
{
    public class GrudController : Controller
    {
        // GET: Grud
        public ActionResult Index()
        {
            IEnumerable<Employee> empobj = null;
            HttpClient hc = new HttpClient();
            hc.BaseAddress = new Uri("http://localhost:53113/api/EmpGrud");

            var consumeapi = hc.GetAsync("EmpGrud");
            consumeapi.Wait();

            var readdata = consumeapi.Result;
            if(readdata.IsSuccessStatusCode)
            {
                var displaydata = readdata.Content.ReadAsAsync<IList<Employee>>();
                displaydata.Wait();

                empobj = displaydata.Result;
            }
            return View(empobj);
        }

        public ActionResult create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult create(EmpClass ec)
        {
            if (ModelState.IsValid)
            {
                HttpClient hc = new HttpClient();
                hc.BaseAddress = new Uri("http://localhost:53113/api/EmpGrud");

                var insertrec = hc.PostAsJsonAsync<EmpClass>("EmpGrud", ec);
                insertrec.Wait();

                var saverec = insertrec.Result;
                if (saverec.IsSuccessStatusCode)
                {
                    ViewBag.message = "The Employee " + ec.Name + " is Inserted Successfully...!";
                    return RedirectToAction("Index");
                }
            }
            return View("Create");
        }
        
        public ActionResult Details(int id)
        {
            EmpClass empobj = null;

            HttpClient hc = new HttpClient();
            hc.BaseAddress = new Uri("http://localhost:53113/api/EmpGrud");

            var consumeapi = hc.GetAsync("EmpGrud?id=" + id);
            consumeapi.Wait();

            var readdata = consumeapi.Result;
            if(readdata.IsSuccessStatusCode)
            {
                var displaydata = readdata.Content.ReadAsAsync<EmpClass>();
                displaydata.Wait();
                empobj = displaydata.Result;
            }
            return View(empobj);
        }

        public ActionResult Edit(int id)
        {
            EmpClass empobj = null;

            HttpClient hc = new HttpClient();
            hc.BaseAddress = new Uri("http://localhost:53113/api/EmpGrud");

            var consumeapi = hc.GetAsync("EmpGrud?id=" + id);
            consumeapi.Wait();

            var readdata = consumeapi.Result;
            if (readdata.IsSuccessStatusCode)
            {
                var displaydata = readdata.Content.ReadAsAsync<EmpClass>();
                displaydata.Wait();
                empobj = displaydata.Result;
            }
            return View(empobj);
        }

        [HttpPost]
        public ActionResult Edit(EmpClass ec)
        {
            HttpClient hc = new HttpClient();
            hc.BaseAddress = new Uri("http://localhost:53113/api/EmpGrud");

            var insertrec = hc.PutAsJsonAsync<EmpClass>("EmpGrud", ec);
            insertrec.Wait();

            var savedata = insertrec.Result;
            if (savedata.IsSuccessStatusCode)
                {                    
                    return RedirectToAction("Index");
                }
                else
                {
                    ViewBag.message = "Employee Record Not Updated...! ";
                }            
            return View(ec);
        }

        public ActionResult Delete(int id)
        {
            HttpClient hc = new HttpClient();
            hc.BaseAddress = new Uri("http://localhost:53113/api/EmpGrud");

            var delrecord = hc.DeleteAsync("EmpGrud/" + id.ToString());
            delrecord.Wait();

            var displaydata = delrecord.Result;
            if(displaydata.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return View("Index");
        }

    }
}