﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPIUserReg.Models;

namespace WebAPIUserReg.Controllers
{
    public class CriGrudController : ApiController
    {
        EmployeeDBEntities nd = new EmployeeDBEntities();
        public IHttpActionResult getcriteria()
        {
            var results = nd.Criteria.ToList();
            return Ok(results);
        }

        [HttpPost]
        public IHttpActionResult criteriaInsert(Criterion criteriaInsert)
        {
            nd.Criteria.Add(criteriaInsert);
            nd.SaveChanges();
            return Ok();
        }

        public IHttpActionResult GetCritId(int id)
        {
            CriteriaClass deitals = null;
            deitals = nd.Criteria.Where(x => x.id == id).Select(x => new CriteriaClass()
            {
                id = x.id,                
                Name = x.Name,                
            }).FirstOrDefault<CriteriaClass>();
            if (deitals == null)
            {
                return NotFound();
            }

            return Ok(deitals);
        }

        public IHttpActionResult Put(CriteriaClass cc)
        {
            var updatecri = nd.Criteria.Where(x => x.id == cc.id).FirstOrDefault<Criterion>();
            if (updatecri != null)
            {
                updatecri.id = cc.id;
                updatecri.Name = cc.Name;                
                nd.SaveChanges();
            }
            else
            {
                return NotFound();
            }
            return Ok();
        }

        public IHttpActionResult Delete(int id)
        {
            var cridel = nd.Criteria.Where(x => x.id == id).FirstOrDefault();
            nd.Entry(cridel).State = System.Data.Entity.EntityState.Deleted;
            nd.SaveChanges();
            return Ok();
        }
    }
}