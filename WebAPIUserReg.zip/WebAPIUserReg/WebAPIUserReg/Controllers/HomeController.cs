﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebAPIUserReg.Models;

namespace WebAPIUserReg.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Title = "Home Page";

            return View();
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(Employee objUser)
        {
            if (ModelState.IsValid)
            {
                using (EmployeeDBEntities db = new EmployeeDBEntities())
                {
                    var obj = db.Employees.Where(a => a.Name.Equals(objUser.Name) && a.Pwd.Equals(objUser.Pwd)).FirstOrDefault();
                    if (obj != null)
                    {
                        Session["UserID"] = obj.ID.ToString();
                        Session["UserName"] = obj.Name.ToString();
                        Session["Role"] = obj.Role;
                        return RedirectToAction("UserDashBoard");
                    }
                }
            }
            return View(objUser);
        }

        public ActionResult UserDashBoard()
        {
            if (Session["UserID"] != null)
            {
                if(Session["Role"].ToString() == "1")
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    return RedirectToAction("IndexEmp");
                }
                //return View();
                //return RedirectToAction("Index");
            }
            else
            {
                ViewBag.message("Incorrect username and password...!");
                return RedirectToAction("Login");
            }
        }  


        //Logout
        public ActionResult Logout()
        {
            Session.Clear();//remove session
            return RedirectToAction("Login");
        }

        public ActionResult IndexEmp()
        {
            ViewBag.Title = "Employer Home Page";

            return View();
        }

    }
}
