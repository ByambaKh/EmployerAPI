﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebAPIUserReg.Models;
using System.Net.Http;

namespace WebAPIUserReg.Controllers
{
    public class GrudCriteriaController : Controller
    {
        // GET: GrudCriteria
        public ActionResult Index()
        {
            IEnumerable<Criterion> criobj = null;
            HttpClient hc = new HttpClient();
            hc.BaseAddress = new Uri("http://localhost:53113/api/CriGrud");

            var consumeapi = hc.GetAsync("CriGrud");
            consumeapi.Wait();

            var readdata = consumeapi.Result;
            if (readdata.IsSuccessStatusCode)
            {
                var displaydata = readdata.Content.ReadAsAsync<IList<Criterion>>();
                displaydata.Wait();

                criobj = displaydata.Result;
            }
            return View(criobj);
        }
       
        public ActionResult create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult create(CriteriaClass ec)
        {
            if (ModelState.IsValid)
            {
                HttpClient hc = new HttpClient();
                hc.BaseAddress = new Uri("http://localhost:53113/api/CriGrud");

                var insertrec = hc.PostAsJsonAsync<CriteriaClass>("CriGrud", ec);
                insertrec.Wait();

                var saverec = insertrec.Result;
                if (saverec.IsSuccessStatusCode)
                {
                    ViewBag.message = "The Criteria " + ec.Name + " is Inserted Successfully...!";
                    return RedirectToAction("Index");
                }
            }
            return View("Create");
        }

        public ActionResult Details(int id)
        {
            CriteriaClass empobj = null;

            HttpClient hc = new HttpClient();
            hc.BaseAddress = new Uri("http://localhost:53113/api/CriGrud");

            var consumeapi = hc.GetAsync("CriGrud?id=" + id);
            consumeapi.Wait();

            var readdata = consumeapi.Result;
            if (readdata.IsSuccessStatusCode)
            {
                var displaydata = readdata.Content.ReadAsAsync<CriteriaClass>();
                displaydata.Wait();
                empobj = displaydata.Result;
            }
            return View(empobj);
        }

        public ActionResult Edit(int id)
        {
            CriteriaClass empobj = null;

            HttpClient hc = new HttpClient();
            hc.BaseAddress = new Uri("http://localhost:53113/api/CriGrud");

            var consumeapi = hc.GetAsync("CriGrud?id=" + id);
            consumeapi.Wait();

            var readdata = consumeapi.Result;
            if (readdata.IsSuccessStatusCode)
            {
                var displaydata = readdata.Content.ReadAsAsync<CriteriaClass>();
                displaydata.Wait();
                empobj = displaydata.Result;
            }
            return View(empobj);
        }

        [HttpPost]
        public ActionResult Edit(CriteriaClass ec)
        {
            HttpClient hc = new HttpClient();
            hc.BaseAddress = new Uri("http://localhost:53113/api/CriGrud");

            var insertrec = hc.PutAsJsonAsync<CriteriaClass>("CriGrud", ec);
            insertrec.Wait();

            var savedata = insertrec.Result;
            if (savedata.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            else
            {
                ViewBag.message = "Criteria Data is not Updated...! ";
            }
            return View(ec);
        }

        public ActionResult Delete(int id)
        {
            HttpClient hc = new HttpClient();
            hc.BaseAddress = new Uri("http://localhost:53113/api/CriGrud");

            var delrecord = hc.DeleteAsync("CriGrud/" + id.ToString());
            delrecord.Wait();

            var displaydata = delrecord.Result;
            if (displaydata.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return View("Index");
        }
    }
}