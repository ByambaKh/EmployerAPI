﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace WebAPIUserReg.Models
{
    public class EmpClass
    {
        public int ID {get; set; }

        [Required(ErrorMessage = "Please Entere the Name")]
        [Display(Name = "Employee Name")]
        public string Name { get; set; }
        
        [DataType(DataType.Password)]
        [Required(ErrorMessage = "Please Entere the Password")]
        [Display(Name = "Password")]
        public string Pwd { get; set; }

        [Required(ErrorMessage = "Please Entere the Re-Password")]
        [Display(Name = "Confirm Password")]
        [Compare("Pwd")]
        public string Repwd { get; set; }

        [Required(ErrorMessage = "Please Entere the Email")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please Select the Gender")]
        [Display(Name = "Gender")]      
        public string Gender { get; set; }

        [Required(ErrorMessage = "Please Enter Date")]
        [Display(Name = "Date of Join")]   
        public DateTime joindate { get; set; }

        [Required(ErrorMessage = "Please Select the Role")]
        [Display(Name = "Role")]    
        public int Role { get; set; }
    }    
}