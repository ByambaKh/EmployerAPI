﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace WebAPIUserReg.Models
{
    public class CriteriaClass
    {
        public int id { get; set; }

        [Required(ErrorMessage = "Please Enter the Criteria Name")]
        [Display(Name = "Criteria Name")]
        public string Name { get; set; }
      
    }
}