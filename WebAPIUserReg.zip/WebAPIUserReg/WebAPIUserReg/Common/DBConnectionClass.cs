﻿using System.Data;
using System.Data.SqlClient;
using System.Text;

using System;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Configuration;

namespace WebAPIUserReg.Common
{
    /// <summary>
    /// DBアクセスクラス
    /// </summary>
    public class DBConnectionClass
    {
        public const bool AccessToMaster = true;
        public const string ApplicationCode = "APPL_CD";
        public const string ApplicationName = "APPL_NAME";
        public const string StartPage = "START_PAGE";
        public const string AcceptCookieLogin = "ACCEPT_COOKIE_LOGIN";
        private const string PSTAttachmentsDirectory = "PastNote";

        #region ユーザー権限関連（ログイン自体は出来ている状態と仮定。）
        public static bool UserAuthorityIs(string auth, string usr = null)
        {
            if (string.IsNullOrEmpty(auth)) return false;
            if (string.IsNullOrEmpty(usr)) usr = System.Web.HttpContext.Current.Session["userid"].ToString().Trim();
            return (GetUserAuthority(usr) == auth.Trim()) ? true : false;
        }
        public static string GetUserAuthority(string usr)
        {
            if (string.IsNullOrEmpty(usr.Trim())) return "";
            return GetOneField(string.Format(" select AUTHORITY from DMS_USER where USERID = '{0}' ", usr.Trim()), "AUTHORITY");
        }
        #endregion

        #region 現在（アプリケーション毎の）トップページにいるかどうか
        public static bool IsTopPageNow()
        {
            return System.Web.HttpContext.Current.Request.FilePath.Contains(GetApplStartPage());
        }
        #endregion

        #region DMS_USER のログインフラグとセッションタイムの更新
        public static bool UserSessionIn(bool sw)
        {
            if (System.Web.HttpContext.Current.Session["userid"] == null) return false;

            ExecSQL(string.Format(@"
                update  DMS_USER
                set     SESSION_TIME = {0}
                ,       LOGIN_FLG = {1}
                where   USERID = '{2}'
            ", (sw) ? " dateadd(MINUTE, " + System.Web.HttpContext.Current.Session.Timeout + ", getdate()) " : "null"
             , (sw) ? "1" : "0"
             , System.Web.HttpContext.Current.Session["userid"].ToString()
             ));

            return true;
        }
        #endregion

        #region 仮想フォルダ名称からアプリケーションの情報を取得
        //VF側からFACILITY_CODEを取り出せるように微修正 20170904 tokunaga
        private static string GetApplInfo(string fld, bool fromVf = false)
        {
            if (!CheckVirtualFolder()) return null;

            if (fromVf == false)
            {

                return GetOneField(" select AP." + fld + @"
                               from DMS_APPLICATIONS as AP inner join DMS_VIRTUAL_FOLDERS as VF on AP.APPL_CD = VF.APPL_CD
                               where VIRTUAL_FOLDER = '" + System.Web.HttpContext.Current.Request.ApplicationPath.ToString() + "'"
                                   , fld
                                   , true);
            }
            else
            {
                return GetOneField(" select VF." + fld + @"
                               from DMS_APPLICATIONS as AP inner join DMS_VIRTUAL_FOLDERS as VF on AP.APPL_CD = VF.APPL_CD
                               where VIRTUAL_FOLDER = '" + System.Web.HttpContext.Current.Request.ApplicationPath.ToString() + "'"
                                   , fld
                                   , true);
            }

        }
        public static string GetApplCode()
        {
            return GetApplInfo("APPL_CD");
        }
        public static string GetApplName()
        {
            return GetApplInfo("APPL_NAME");
        }
        public static string GetApplStartPage()
        {
            return GetApplInfo("START_PAGE");
        }
        public static bool AllowCookieLogin()
        {
            return (GetApplInfo("ACCEPT_COOKIE_LOGIN").ToUpper() == "TRUE") ? true : false;
        }
        public static bool AllowMultiLogin()
        {
            return (GetApplInfo("ACCEPT_MULTI_LOGIN").ToUpper() == "TRUE") ? true : false;
        }
        public static string GetFacilityCode() //20170904 tokunaga add
        {
            return GetApplInfo("FACILITY_CD", true);
        }
        #endregion

        #region セッション変数取得用
        public static string CurrentUser()
        {
            if (System.Web.HttpContext.Current.Session["userid"] == null) return null;
            return System.Web.HttpContext.Current.Session["userid"].ToString().Trim();
        }
        #endregion

        #region アプリケーションの使用可否を判断
        public static bool IsApplicationAllowed()
        {
            string enbl = GetSystemSetting("ENABLE", GetApplInfo("APPL_CD"));

            if (string.IsNullOrEmpty(enbl)) return false;
            if (string.Compare(enbl, "TRUE") != 0) return false;
            return true;
        }
        #endregion

        #region ページの使用可否を判断
        public static bool IsPageAllowed(string pg = null, string usr = null)
        {
            if (pg == null) pg = System.IO.Path.GetFileName(System.Web.HttpContext.Current.Request.FilePath.ToString().Trim());
            pg = System.IO.Path.GetFileName(pg);
            if (usr == null) usr = CurrentUser();
            if (0 >= GetNoOfRow("DMS_V_MENUS", string.Format(" charindex((select USR.AUTHORITY from DMS_USER as USR where USR.USERID = '{0}'), AUTHORITIES) > 0 and PAGE_NAME = '{1}'", usr, pg)))
                return false;
            return true;
        }
        #endregion

        #region コールされた仮想フォルダが存在するかどうかのチェック
        public static bool CheckVirtualFolder()
        {
            string vf = System.Web.HttpContext.Current.Request.ApplicationPath.ToString();

            if (vf.Trim().Length <= 0) return false;

            SqlConnection objConn = DBConnect();

            DataTable dt = new DataTable();

            //using (SqlDataAdapter adpt = new SqlDataAdapter(" select DB_NAME from DMS_FACILITIES where FACILITY_CD = '" + fc + "' ", objConn))
            using (SqlDataAdapter adpt = new SqlDataAdapter(@"
                    select FC.DB_NAME
                    from DMS_VIRTUAL_FOLDERS as VF inner join DMS_FACILITIES as FC on VF.FACILITY_CD = FC.FACILITY_CD
                    where VF.VIRTUAL_FOLDER = '" + vf + "' ", objConn))
            {
                adpt.Fill(dt);
            }

            if (dt == null || dt.Rows.Count <= 0) { objConn.Close(); return false; }

            string dbname = dt.Rows[0]["DB_NAME"].ToString();
            dt.Clear();
            using (SqlDataAdapter adpt = new SqlDataAdapter(" select name from sys.databases where name = '" + dbname + "' ", objConn))
            {
                adpt.Fill(dt);
            }

            if (dt == null || dt.Rows.Count <= 0) { objConn.Close(); return false; }

            objConn.Close();
            return true;
        }
        #endregion

        #region DB接続
        /// <summary>
        /// DB接続
        /// </summary>
        /// <returns>DB接続クラス</returns>
        public static SqlConnection DBConnect()
        {
           
            string connStr = "";
            SqlConnection objConn;

            //if (System.Web.HttpContext.Current.Session["FACILITY_CODE"] == null)
            //{
            //    CommonClass.Logoff();
            //    //System.Web.HttpContext.Current.Response.Redirect("login.aspx");
            //    return null;
            //}

            connStr = string.Format("Data Source={0};Initial Catalog={1};User ID={2};Password={3};",
                                    ConfigurationManager.AppSettings["DataSource"],
                                    ConfigurationManager.AppSettings["InitialCatalog"],
                                    ConfigurationManager.AppSettings["UserID"],
                                    ConfigurationManager.AppSettings["Password"]);
            objConn = new SqlConnection(connStr);
            objConn.Open();

            if ((System.Web.HttpContext.Current.Session["DB_NAME"] == null))
            {
               
                //if(ToMaster) return objConn;   // MASTERへの接続の場合ここで返す。
                //return objConn;
//                DataTable dt = new DataTable();

//                //                using (SqlDataAdapter adpt = new SqlDataAdapter(" select DB_NAME from DMS_FACILITIES where FACILITY_CD = '" + System.Web.HttpContext.Current.Session["FACILITY_CODE"].ToString() + "' ", objConn))
//                //                using (SqlDataAdapter adpt = new SqlDataAdapter(" select DB_NAME from DMS_FACILITIES where FACILITY_CD = '" + System.Web.HttpContext.Current.Request.ApplicationPath.ToString().Replace("/", "") + "' ", objConn))
//                using (SqlDataAdapter adpt = new SqlDataAdapter(@" 
//                    select FC.DB_NAME
//                    from DMS_VIRTUAL_FOLDERS as VF inner join DMS_FACILITIES as FC on VF.FACILITY_CD = FC.FACILITY_CD
//                    where VF.VIRTUAL_FOLDER = '"
//                    + System.Web.HttpContext.Current.Request.ApplicationPath.ToString() + "' ", objConn))
//                {
//                    adpt.Fill(dt);
//                }

//                if (dt == null || dt.Rows.Count == 0) return null;

//                System.Web.HttpContext.Current.Session["DB_NAME"] = dt.Rows[0]["DB_NAME"].ToString();

//                objConn.Close();
            }

            //connStr = string.Format("Data Source={0};Initial Catalog={1};User ID={2};Password={3};",
            //                    ConfigurationManager.AppSettings["DataSource"],
            //                    System.Web.HttpContext.Current.Session["DB_NAME"],
            //                    ConfigurationManager.AppSettings["UserID"],
            //                    ConfigurationManager.AppSettings["Password"]);
            //objConn = new SqlConnection(connStr);
            //objConn.Open();

            return objConn;
        }
        #endregion

        #region データ取得(トランザクション内）tokunaga20160929add
        /// <summary>
        /// データ取得(トランザクション内）tokunaga20160929add
        /// </summary>
        /// <param name="sql">SQL</param>
        /// <returns></returns>
        public static DataTable GetRecordsTran(string sql, SqlTransaction tran, SqlCommand command)
        {
            DataTable dt = new DataTable();

            using (SqlDataAdapter adpt = new SqlDataAdapter())
            {
                command.CommandText = sql;
                command.Transaction = tran;
                adpt.SelectCommand = command;
                adpt.Fill(dt);
            }

            return dt;
        }
        #endregion


        #region データ取得(トランザクション内、1行のみ) tokunaga20161026add
        /// <summary>
        /// データ取得(トランザクション内、1行のみ) tokunaga20161026add
        /// </summary>
        /// <param name="sql">SQL</param>
        /// <returns></returns>
        public static DataRow GetOneRowTran(string sql, SqlTransaction tran, SqlCommand command)
        {
            DataRow dr = null;

            DataTable dt = GetRecordsTran(sql, tran, command);
            if (dt.Rows.Count > 0)
            {
                dr = dt.Rows[0];
            }

            return dr;
        }
        #endregion

        #region データ取得(トランザクション内、1行 かつ 指定したフィールドのみ) tokunaga20161026add
        /// <summary>
        /// データ取得(トランザクション内、1行 かつ 指定したフィールドのみ) tokunaga20161026add
        /// </summary>
        /// <param name="sql">SQL</param>
        /// <param name="field">フィールド名</param>
        /// <returns></returns>
        public static string GetOneFieldTran(string sql, string field, SqlTransaction tran, SqlCommand command)
        {
            string value = null;

            DataRow dr = GetOneRowTran(sql, tran, command);
            if (dr != null && dr.Table.Columns.Contains(field))
            {
                value = dr[field].ToString();
            }

            return value;
        }
        #endregion

        #region データ取得
        /// <summary>
        /// データ取得
        /// </summary>
        /// <param name="sql">SQL</param>
        /// <returns></returns>
        public static DataTable GetRecords(string sql, bool ToMaster = false)
        {
            DataTable dt = new DataTable();

            SqlConnection objConn = DBConnect();

            if (objConn == null) return null;   // 接続出来ていなかった場合NULLで終了
            using (SqlDataAdapter adpt = new SqlDataAdapter(sql, objConn))
            {
                adpt.Fill(dt);
            }
            objConn.Close();

            return dt;
        }
        #endregion

        #region データ取得(1行のみ)
        /// <summary>
        /// データ取得(1行のみ)
        /// </summary>
        /// <param name="sql">SQL</param>
        /// <returns></returns>
        public static DataRow GetOneRow(string sql, bool ToMaster = false)
        {
            DataRow dr = null;

            DataTable dt = GetRecords(sql, ToMaster);
            if (dt.Rows.Count > 0)
            {
                dr = dt.Rows[0];
            }

            return dr;
        }
        #endregion

        #region データ取得(1行 かつ 指定したフィールドのみ)
        /// <summary>
        /// データ取得(1行 かつ 指定したフィールドのみ)
        /// </summary>
        /// <param name="sql">SQL</param>
        /// <param name="field">フィールド名</param>
        /// <returns></returns>
        public static string GetOneField(string sql, string field, bool ToMaster = false)
        {
            string value = null;

            DataRow dr = GetOneRow(sql, ToMaster);
            if (dr != null && dr.Table.Columns.Contains(field))
            {
                value = dr[field].ToString().Trim();
            }

            return value;
        }
        #endregion

        #region get Data
        /// <summary>
        /// Data search
        /// </summary>     
        /// <returns></returns>
        public static int GetNoOfRow(string table, string where = null, bool ToMaster = false)
        {
            StringBuilder sql = new StringBuilder();
            sql.Append("SELECT ");
            sql.Append(" * ");
            sql.Append("FROM ");
            sql.AppendFormat(" {0} ", table);
            if (!string.IsNullOrEmpty(where))
            {
                sql.AppendFormat("WHERE {0} ", where);
            }
            DataTable dt = GetRecords(sql.ToString(), ToMaster);

            return dt.Rows.Count;
        }
        #endregion

        #region レコードが存在するかどうかのチェック
        /// <summary>
        /// データ数取得
        /// </summary>
        /// <param name="table">テーブル名</param>
        /// <param name="where">抽出条件</param>
        /// <returns></returns>
        public static bool DoesExist(string table, string where = null, bool ToMaster = false)
        {
            if (DBConnectionClass.GetNoOfRow(table, where, ToMaster) > 0)
                return true;
            else
                return false;
        }
        #endregion

        #region SQL実行(登録/更新系)
        /// <summary>
        /// SQL実行(登録/更新系)
        /// </summary>
        /// <param name="command">コマンド</param>
        /// <param name="tran">トランザクション</param>
        /// <param name="strSQL">SQL</param>
        public static void ExecuteSQL(SqlCommand command, SqlTransaction tran, string strSQL)
        {
            command.Transaction = tran;
            command.CommandText = strSQL;
            command.ExecuteNonQuery();
        }
        #endregion

        #region SQL実行(トランザクション無し)
        /// <summary>
        /// SQL実行(トランザクション無し)
        /// </summary>
        /// <param name="strSQL">SQL</param>
        public static void ExecSQL(string strSQL, bool ToMaster = false)
        {
            SqlConnection oConn = DBConnect();
            SqlCommand command = oConn.CreateCommand();
            SqlTransaction tran = oConn.BeginTransaction(IsolationLevel.ReadCommitted);
            ExecuteSQL(command, tran, strSQL.ToString());
            tran.Commit();
            oConn.Close();
        }
        #endregion

        #region ストアドプロシージャ実行
        /// <summary>
        /// パラメータ設定
        /// </summary>
        /// <param name="parameterName">パラメーター名</param>
        /// <param name="sqlDbType">データ型</param>
        /// <param name="size">パラメーターの長さ</param>
        /// <param name="value">設定値</param>
        /// <returns></returns>
        public static SqlParameter SetParamSP(string parameterName, SqlDbType sqlDbType, int size, object value)
        {
            SqlParameter pm = new SqlParameter();
            pm.ParameterName = parameterName;
            pm.SqlDbType = sqlDbType;
            pm.Size = size;
            pm.Value = value;

            return pm;
        }

        /// <summary>
        /// ストアドプロシージャ実行
        /// </summary>
        /// <param name="proc">プロシージャ名</param>
        /// <param name="param">パラメータ</param>
        /// <returns></returns>
        public static int ExceSP(string proc, params SqlParameter[] param)
        {
            int retVal = 0;

            SqlConnection objConn = DBConnect();
            using (SqlDataAdapter adpt = new SqlDataAdapter(proc, objConn))
            {
                SqlCommand cmd = adpt.SelectCommand;
                //実行タイプに”ストアドプロシージャ”を設定
                cmd.CommandType = CommandType.StoredProcedure;
                //パラメータ設定
                foreach (SqlParameter pm in param)
                {
                    cmd.Parameters.Add(pm.ParameterName, pm.SqlDbType, pm.Size).Value = pm.Value;
                }
                //パラメータ設定(戻り値)
                cmd.Parameters.Add("@RetValue", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                //ストアドプロシージャ実行
                adpt.Fill(new DataTable());
                //戻り値の取得
                retVal = int.Parse(cmd.Parameters["@RetValue"].Value.ToString());
            }
            objConn.Close();

            return retVal;
        }
        #endregion

        #region ユーザ権限チェック
        /// <summary>
        /// ユーザ権限チェック
        /// </summary>
        /// <param name="Userid">ユーザID</param>
        /// <param name="Password">パスワード</param>
        /// <returns></returns>
        public static DataRow CheckUserAuthority(string Userid, string Password = "")
        {
            DataRow dr = null;

            //データ取得・表示
            StringBuilder sql = new StringBuilder();
            sql.Append("SELECT USERID, USERMANE, AUTHORITY FROM ");
            sql.Append(" DMS_USER ");
            sql.AppendFormat("WHERE USERID = '{0}' ", Userid);
            if (Password != "")
            {
                Password = EncryptString(Password, ConfigurationManager.AppSettings["Password"]);
                sql.AppendFormat(" AND PASSWORD = '{0}' ", Password);
            }

            DataTable dt = DBConnectionClass.GetRecords(sql.ToString());
            if (dt == null) return null;

            //データが存在する場合
            if (dt.Rows.Count != 0)
            {
                dr = dt.Rows[0];
            }
            return dr;
        }
        #endregion

        /// <summary>
        /// 文字列を暗号化する
        /// </summary>
        /// <param name="sourceString">暗号化する文字列</param>
        /// <param name="password">暗号化に使用するパスワード</param>
        /// <returns>暗号化された文字列</returns>
        public static string EncryptString(string sourceString, string password)
        {
            //RijndaelManagedオブジェクトを作成
            System.Security.Cryptography.RijndaelManaged rijndael =
                new System.Security.Cryptography.RijndaelManaged();

            //パスワードから共有キーと初期化ベクタを作成
            byte[] key, iv;
            GenerateKeyFromPassword(
                password, rijndael.KeySize, out key, rijndael.BlockSize, out iv);
            rijndael.Key = key;
            rijndael.IV = iv;

            //文字列をバイト型配列に変換する
            byte[] strBytes = System.Text.Encoding.UTF8.GetBytes(sourceString);

            //対称暗号化オブジェクトの作成
            System.Security.Cryptography.ICryptoTransform encryptor =
                rijndael.CreateEncryptor();
            //バイト型配列を暗号化する
            byte[] encBytes = encryptor.TransformFinalBlock(strBytes, 0, strBytes.Length);
            //閉じる
            encryptor.Dispose();

            //バイト型配列を文字列に変換して返す
            return System.Convert.ToBase64String(encBytes);
        }

        /// <summary>
        /// 暗号化された文字列を復号化する
        /// </summary>
        /// <param name="sourceString">暗号化された文字列</param>
        /// <param name="password">暗号化に使用したパスワード</param>
        /// <returns>復号化された文字列</returns>
        public static string DecryptString(string sourceString, string password)
        {
            //RijndaelManagedオブジェクトを作成
            System.Security.Cryptography.RijndaelManaged rijndael =
                new System.Security.Cryptography.RijndaelManaged();

            //パスワードから共有キーと初期化ベクタを作成
            byte[] key, iv;
            GenerateKeyFromPassword(
                password, rijndael.KeySize, out key, rijndael.BlockSize, out iv);
            rijndael.Key = key;
            rijndael.IV = iv;

            //文字列をバイト型配列に戻す
            byte[] strBytes = System.Convert.FromBase64String(sourceString);

            //対称暗号化オブジェクトの作成
            System.Security.Cryptography.ICryptoTransform decryptor =
                rijndael.CreateDecryptor();
            //バイト型配列を復号化する
            //復号化に失敗すると例外CryptographicExceptionが発生
            byte[] decBytes = decryptor.TransformFinalBlock(strBytes, 0, strBytes.Length);
            //閉じる
            decryptor.Dispose();

            //バイト型配列を文字列に戻して返す
            return System.Text.Encoding.UTF8.GetString(decBytes);
        }

        /// <summary>
        /// パスワードから共有キーと初期化ベクタを生成する
        /// </summary>
        /// <param name="password">基になるパスワード</param>
        /// <param name="keySize">共有キーのサイズ（ビット）</param>
        /// <param name="key">作成された共有キー</param>
        /// <param name="blockSize">初期化ベクタのサイズ（ビット）</param>
        /// <param name="iv">作成された初期化ベクタ</param>
        private static void GenerateKeyFromPassword(string password,
            int keySize, out byte[] key, int blockSize, out byte[] iv)
        {
            //パスワードから共有キーと初期化ベクタを作成する
            //saltを決める
            byte[] salt = System.Text.Encoding.UTF8.GetBytes("saltは必ず8バイト以上");
            //Rfc2898DeriveBytesオブジェクトを作成する
            System.Security.Cryptography.Rfc2898DeriveBytes deriveBytes =
                new System.Security.Cryptography.Rfc2898DeriveBytes(password, salt);
            //.NET Framework 1.1以下の時は、PasswordDeriveBytesを使用する
            //System.Security.Cryptography.PasswordDeriveBytes deriveBytes =
            //    new System.Security.Cryptography.PasswordDeriveBytes(password, salt);
            //反復処理回数を指定する デフォルトで1000回
            deriveBytes.IterationCount = 1000;

            //共有キーと初期化ベクタを生成する
            key = deriveBytes.GetBytes(keySize / 8);
            iv = deriveBytes.GetBytes(blockSize / 8);
        }

        #region 履歴データ保存
        /// <summary>
        /// 履歴データ保存
        /// </summary>
        /// <param name="Tablename">テーブル名</param>
        /// <param name="Keyname">キー項目名</param>
        /// <param name="Keyid">キーID</param>
        /// <param name="userid">ログインID</param>
        /// <param name="delflg">削除区分</param>
        /// <returns></returns>
        public static bool TakeHistorical(string Tablename, string Keyname, string Keyid, string userid, int delflg = 0)
        {
            DataRow dr = null;
            //データ取得・表示
            StringBuilder sql = new StringBuilder();
            DataTable dt;
            string strColumns = "";
            SqlConnection oConn;
            //削除時、削除前の該当レコードを履歴コピー
            if (delflg == 1)
            {
                //データ取得・表示
                sql = new StringBuilder();
                sql.Append("SELECT * FROM ");
                sql.Append(Tablename);
                sql.AppendFormat(" WHERE " + Keyname + " = '{0}' ", Keyid);

                dt = DBConnectionClass.GetRecords(sql.ToString());

                //データが存在する場合
                if (dt.Rows.Count != 0)
                {
                    dr = dt.Rows[0];
                    //トランザクション制御
                    oConn = DBConnectionClass.DBConnect();
                    using (SqlCommand command = oConn.CreateCommand())
                    {
                        SqlTransaction tran = oConn.BeginTransaction(IsolationLevel.ReadCommitted);
                        try
                        {
                            StringBuilder strSQL = new StringBuilder();
                            strSQL.Append("INSERT INTO ");
                            //取得データを履歴テーブルにコピー
                            //各テーブルのカラム名は、取得データ配列に応じて設定
                            strSQL.Append(Tablename + "_HIST ( ");
                            for (int i = 1; i < dt.Columns.Count; i++)
                            {
                                if (i == 1)
                                {
                                    strColumns = dt.Columns[i].ColumnName;
                                }
                                else
                                {
                                    strColumns = strColumns + ", " + dt.Columns[i].ColumnName;
                                }
                            }
                            strSQL.Append(strColumns);
                            strSQL.Append(") VALUES ( ");
                            //取得データ配列に応じて、カラム数分設定
                            for (int i = 1; i < (dt.Columns.Count); i++)
                            {
                                if (i != (dt.Columns.Count - 1))
                                {
                                    strSQL.AppendFormat(" '{0}', ", dr.ItemArray[i]);
                                }
                                else
                                {
                                    strSQL.AppendFormat(" '{0}' ", dr.ItemArray[i]);
                                }
                            }
                            strSQL.Append(") ");
                            DBConnectionClass.ExecuteSQL(command, tran, strSQL.ToString());
                            tran.Commit();
                        }
                        catch (Exception)
                        {
                            tran.Rollback();
                            return false;
                        }
                        oConn.Dispose();
                    }

                }
            }

            //データ取得・表示
            sql = new StringBuilder();
            sql.Append("SELECT * FROM ");
            sql.Append(Tablename);
            sql.AppendFormat(" WHERE " + Keyname + " = '{0}' ", Keyid);

            dt = DBConnectionClass.GetRecords(sql.ToString());

            //データが存在する場合
            if (dt.Rows.Count != 0)
            {
                dr = dt.Rows[0];
                //トランザクション制御
                oConn = DBConnectionClass.DBConnect();
                using (SqlCommand command = oConn.CreateCommand())
                {
                    SqlTransaction tran = oConn.BeginTransaction(IsolationLevel.ReadCommitted);
                    try
                    {
                        StringBuilder strSQL = new StringBuilder();
                        strSQL.Append("INSERT INTO ");
                        //取得データを履歴テーブルにコピー
                        //各テーブルのカラム名は、取得データ配列に応じて設定
                        strSQL.Append(Tablename + "_HIST ( ");
                        for (int i = 1; i < dt.Columns.Count; i++)
                        {
                            if (i == 1)
                            {
                                strColumns = dt.Columns[i].ColumnName;
                            }
                            else
                            {
                                strColumns = strColumns + ", " + dt.Columns[i].ColumnName;
                            }
                        }
                        strSQL.Append(strColumns);
                        strSQL.Append(") VALUES ( ");
                        //取得データ配列に応じて、カラム数分設定
                        for (int i = 1; i < (dt.Columns.Count); i++)
                        {

                            //以下応急対応でカラム順で更新日とユーザーIDを固定してしまっているので、変更が加わった場合要注意_20150925tokunaga change
                            if (dr.ItemArray[i].GetType().Name == "Int32")
                            {
                                strSQL.AppendFormat(" {0}", dr.ItemArray[i]);
                            }
                            else if (i == 6)
                            {
                                strSQL.AppendFormat(" '{0}'", userid);
                            }
                            else if (i == 7)
                            {
                                strSQL.AppendFormat(" '{0}'", DateTime.Now);
                            }
                            else
                            {
                                strSQL.AppendFormat(" '{0}'", dr.ItemArray[i]);
                            }

                            if (dt.Columns.Count != i + 1)
                            {
                                strSQL.AppendFormat(" , ");
                            }

                        }

                        //USERテーブルにカラム追加したため、順序変更となり後付では対応できないため、上のループ内でとりあえずベタ対応_20150925tokunaga change
                        //strSQL.AppendFormat(" '{0}', ", userid);
                        //strSQL.AppendFormat(" '{0}' ", DateTime.Now);
                        strSQL.Append(") ");
                        DBConnectionClass.ExecuteSQL(command, tran, strSQL.ToString());
                        tran.Commit();
                    }
                    catch (Exception)
                    {
                        tran.Rollback();
                        return false;
                    }
                    oConn.Dispose();
                }

            }
            return true;
        }
        #endregion

        #region 履歴データ取得
        /// <summary>
        /// 履歴データ保存
        /// </summary>
        /// <param name="Tablename">テーブル名</param>
        /// <param name="Keyname">キー項目名</param>
        /// <param name="Keyid">キーID</param>
        /// <param name="userid">更新日時</param>
        /// <returns></returns>
        public static DataRow GetDataIncludingHistorical(string Tablename, string Keyname, string Keyid, DateTime datetime)
        {
            DataRow dr = null;
            //データ取得・表示
            StringBuilder sql = new StringBuilder();
            DataTable dt;

            //データ取得・表示
            sql = new StringBuilder();
            sql.Append("SELECT * FROM ");
            sql.Append(Tablename);
            sql.AppendFormat(" WHERE " + Keyname + " = '{0}' ", Keyid);
            sql.AppendFormat(" AND UPDATE_DATE = '{0}' ", datetime);

            dt = DBConnectionClass.GetRecords(sql.ToString());

            if (dt.Rows.Count > 0)
            {
                dr = dt.Rows[0];
            }

            return dr;
        }
        #endregion

        #region 文言データの取得
        /// <summary>
        /// 文言データの取得
        /// </summary>
        /// <param name="keyword">KEYWORD</param>
        /// <param name="keycode">KEY_CODE</param>
        /// <param name="wordtype">文言の種別</param>
        /// <returns></returns>
        public static string GetWord(string keyword, string keycode, string wordtype)
        {
            string sSQL = string.Format(@"
select  {0} as TARGET_WORD
from    DMS_WORDS
where   KEYWORD = '{1}'
and     KEY_CODE = '{2}'  "
            , wordtype
            , keyword
            , keycode
            );

            return GetOneField(sSQL, "TARGET_WORD");
        }
        #endregion


        #region 文言データからグリッドビュー内のドロップダウンリスト生成
        /// <summary>
        /// 文言データからグリッドビュー内のドロップダウンリスト生成//tokunaga20161221 add
        /// </summary>
        /// <param name="ddlObj">ドロップダウンリスト</param>
        /// <param name="keyword">KEYWORD</param>
        /// <returns></returns>
        public static void setGridDdlList(string ctlName, GridViewRowEventArgs e, string searchWord, bool emptyFlg)
        {

            DropDownList ddlControl = (DropDownList)e.Row.FindControl(ctlName);
            string sSQL = string.Format(@"
select  KEY_CODE
,       SHORT_WORD
,       DISP_ORDER
FROM    DMS_WORDS
WHERE   KEYWORD = '{0}' "
            , searchWord);
            DataTable dt = DBConnectionClass.GetRecords(sSQL);
            if (emptyFlg == true)
            {
                ddlControl.Items.Add(new ListItem("未選択", ""));
            }
            foreach (DataRow row in dt.Rows)
            {
                ddlControl.Items.Add(new ListItem(row["SHORT_WORD"].ToString(), row["KEY_CODE"].ToString()));
            }

        }
        #endregion

        #region 基本情報テーブルからシステム情報を取得
        public static string GetSysInfo(string key, string def_val = null)
        {
            try
            {
                string retval;
                retval = GetOneField(string.Format(" SELECT TOP 1 {0} FROM DMS_BASIC_INFO ", key), key);
                return (string.IsNullOrEmpty(retval)) ? def_val : retval;
            }
            catch
            {
                throw;
            }

        }
        #endregion

        #region システム設定値を取得
        public static string GetSystemSetting(string cat, string key, string def_val = null)
        {
            try
            {
                if (string.IsNullOrEmpty(cat.Trim()) || string.IsNullOrEmpty(key.Trim())) return def_val;

                if (System.Web.HttpContext.Current.Session[cat + key] == null)
                    System.Web.HttpContext.Current.Session[cat + key]
                        = DBConnectionClass.GetOneField(string.Format(" SELECT VALUE FROM DMS_SYSTEM_SETTINGS WHERE CATEGORY = '{0}' AND KEY_CODE = '{1}' ", cat, key), "VALUE");

                if (System.Web.HttpContext.Current.Session[cat + key] == null) return null;

                return System.Web.HttpContext.Current.Session[cat + key].ToString();
            }
            catch
            {
                throw;
            }

        }
        #endregion

        #region 実テーブルから空の DataRow を作成（全項目 String 型）
        public static DataRow NewDataRow(string tbl_name)
        {
            DataTable ndt = new DataTable();

            DataTable dt = GetRecords(" select top 1 * from " + tbl_name);

            for (int i = 0; i < dt.Columns.Count; i++)
            {
                ndt.Columns.Add(dt.Columns[i].ColumnName, Type.GetType("System.String"));
            }

            DataRow dr = ndt.NewRow();

            dt.Dispose();
            ndt.Dispose();

            return dr;
        }
        #endregion


        #region 文言データの取得(M_OPTION_VALUESテーブル版）
        /// <summary>
        /// 文言データの取得(M_OPTION_VALUESテーブル版）20170727 tokunaga add
        /// </summary>
        /// <param name="keyword">KEYWORD</param>
        /// <param name="keycode">KEY_CODE</param>
        /// <param name="wordtype">文言の種別</param>
        /// <returns></returns>
        public static string GetOptionValues(string targetColumn, string optionType, string keyCode)
        {
            string sSQL = string.Format(@"
SELECT {0} AS TARGET_WORD FROM M_OPTION_VALUES WHERE OPTION_TYPE = '{1}' AND KEY_CODE = '{2}' "
            , targetColumn
            , optionType
            , keyCode
            );

            return GetOneField(sSQL, "TARGET_WORD");
        }
        #endregion

    }
}