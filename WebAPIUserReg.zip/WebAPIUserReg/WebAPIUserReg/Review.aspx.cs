﻿using System;
using System.Security;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Drawing;
using System.IO;             //for StreamReader
using System.Diagnostics;    //for Stopwatch
using Microsoft.VisualBasic; //for StrConv
using System.Text.RegularExpressions;
using System.Globalization; //for DateTime.ParseExtract
using System.Reflection;
using System.Web.UI.HtmlControls; 

using System.Web.UI;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Net; 

namespace WebAPIUserReg
{
    public partial class Review : System.Web.UI.Page
    {
        #region
        private const string cDEFAULT_DDL_VAL = "0";
        private const string cDEFAULT_DDL_ITEM = "Select";
        private const string cNULL = "NULL";

        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
           

            if (!this.IsPostBack)
            {
                string sql = "Select ID,Name from Employees";
                PrepareDDL(ddlEmployers, sql, cDEFAULT_DDL_VAL, cDEFAULT_DDL_ITEM);

                DataTable dt = new DataTable();
                DataRow dr = null;
                dt.Columns.Add(new DataColumn("id", typeof(int)));
                dt.Columns.Add(new DataColumn("RevEmpId", typeof(int)));
                dr = dt.NewRow();
                dr["id"] = 1;
                dr["RevEmpId"] = 1;
                dt.Rows.Add(dr);

                gvEmployers.DataSource = dt; //Common.DBConnectionClass.GetRecords(sql);
                gvEmployers.DataBind();

                Session["gvEmployer"] = dt;
            }
        }


        public static int PrepareDDL(DropDownList targetDdl, string sql, string default_val = "", string default_item = "")
        {
            try
            {
                DataTable dt = Common.DBConnectionClass.GetRecords(sql);
                targetDdl.Items.Clear();

                if (dt.Rows.Count > 0)
                {
                    targetDdl.DataSource = dt;
                    targetDdl.DataValueField = dt.Columns[0].ColumnName.ToString();
                    targetDdl.DataTextField = dt.Columns[1].ColumnName.ToString();
                    targetDdl.DataBind();
                }
                else
                {
                    return 0;
                }

                if (default_val == "") return 1;

                ListItem addNew = new ListItem();
                addNew.Text = default_item;
                addNew.Value = default_val;
                targetDdl.Items.Insert(0, addNew);
                return 1;

            }
            catch
            {
                throw;
            }
        }
        
        protected void btnAddRow_Click(object sender, EventArgs e)
        {
            //save data for postback
            SaveData_gvEmployer();

            DataTable dt = Session["gvEmployer"] as DataTable;            
            DataTable gvEmployerDT = dt;
            int rowID = 0;
            // DataRow
            foreach (GridViewRow gvEmployer_Row in gvEmployers.Rows)
            {
                HiddenField rowid = (HiddenField)gvEmployer_Row.FindControl("hdnRowId");
                rowID = int.Parse(rowid.Value);
                DropDownList ddlEmployerName = (DropDownList)gvEmployer_Row.FindControl("ddlEmployerName");
            }

            // Addrow
            DataRow dr = null;            
            dr = dt.NewRow();
            dr["id"] = string.Empty; // rowID + 1;
            dr["Name"] = string.Empty;
           
            gvEmployerDT.Rows.Add(dr);
            gvEmployers.DataSource = gvEmployerDT;
            gvEmployers.DataBind();

            ////Focus in
            //GridViewRow lastRow = gvMoisture.Rows[gvMoisture.Rows.Count - 1];
            //DropDownList ddlrowMethod = (DropDownList)lastRow.FindControl("ddlseedMethod");
            //ddlrowMethod.Focus();
        }

        #region 
        private void SaveData_gvEmployer()
        {
            DataTable dt = Session["gvEmployer"] as DataTable;   

            int j = 0;
            for (int i = 0; i < gvEmployers.Rows.Count; i++)
            {
                dt.Rows[j]["Name"] = GetGridDDLVal(gvEmployers.Rows[i], "ddlEmployerName");
                //dt.Rows[j]["rowID"] = (HiddenField)gvEmployers.FindControl("hdnRowId");
                //HiddenField rowid = (HiddenField)gvEmployers.FindControl("hdnRowId");
                j++;
            }

            dt.AcceptChanges();
        }
        #endregion

        #region get DDLValue From Grid
        private string GetGridDDLVal(GridViewRow gr, string objname)
        {
            return string.IsNullOrEmpty(((DropDownList)gr.FindControl(objname)).SelectedValue) ? "" : ((DropDownList)gr.FindControl(objname)).SelectedValue;
        }

        protected string IntToDB(string val, string empty = cNULL)
        {
            return string.IsNullOrEmpty(val.Trim()) ? empty : val.Replace(",", "");
        }
        #endregion

        //        protected void gvEmployers_RowCreated(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
//        {
//            switch (e.Row.RowType)
//            {
//                case DataControlRowType.Header:                   
//                    e.Row.TableSection = TableRowSection.TableHeader;
//                    break;
//                case DataControlRowType.DataRow:                    
//                    // e.Row.TableSection = TableRowSection.TableBody;
//                    break;
//                case DataControlRowType.Footer:                    
//                    e.Row.TableSection = TableRowSection.TableFooter;
//                    break;
//                case DataControlRowType.Pager:                   
//                    e.Row.TableSection = TableRowSection.TableHeader;
//                    break;
//            }

//            if (e.Row.RowType == DataControlRowType.DataRow)
//            {
//                DropDownList ddlEmployerName = (DropDownList)e.Row.FindControl("ddlEmployerName");

//                string sql_B = @"
//               Select ID, Name from Employees ";

//                DataTable dt_B = Common.DBConnectionClass.GetRecords(sql_B.ToString());
//                ddlEmployerName.Items.Add(new ListItem());

//                foreach (DataRow row in dt_B.Rows)
//                {
//                    ddlEmployerName.Items.Add(new ListItem(row["Name"].ToString(), row["ID"].ToString()));

//                }
//            }
//        }

        protected void gvEmployers_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //Find the DropDownList in the Row
                DropDownList ddlEmployerName = (e.Row.FindControl("ddlEmployerName") as DropDownList);
                string sql = "";

                if (ddlEmployers.SelectedValue.ToString() != "0")
                {
//                    sql = @" select RevEmployers.id, RevEmpId, Name from RevEmployers 
//                                left join Employees on Employees.ID = RevEmployers.RevEmpId
//                                where EmpId = " + ddlEmployers.SelectedValue;

//                    ddlEmployerName.SelectedValue = 
//                    ddlEmployerName.DataSource = Common.DBConnectionClass.GetRecords(sql);
//                    ddlEmployerName.DataTextField = "Name";
//                    ddlEmployerName.DataValueField = "RevEmpId";
//                    ddlEmployerName.DataBind();
                }
                else
                {
                    string ssql = "Select ID, Name from Employees";
                    ddlEmployerName.DataSource = Common.DBConnectionClass.GetRecords(ssql);
                    ddlEmployerName.DataTextField = "Name";
                    ddlEmployerName.DataValueField = "ID";
                    ddlEmployerName.DataBind();

                    //Add Default Item in the DropDownList
                    ddlEmployerName.Items.Insert(0, new ListItem("Please select"));
                }
                
               
              
            }
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            SqlConnection oConn = Common.DBConnectionClass.DBConnect();
            SqlCommand command = oConn.CreateCommand();
            SqlTransaction tran = oConn.BeginTransaction(IsolationLevel.ReadCommitted);
            DataRow drRevEmployers = Common.DBConnectionClass.NewDataRow("RevEmployers");

            int EmpId = int.Parse(ddlEmployers.SelectedValue);

            foreach (GridViewRow gr in gvEmployers.Rows)
                {
                    string hdnRowId = ((HiddenField)gr.FindControl("hdnRowId")).Value;

                    //checkbox for delete id collect
                    if (((CheckBox)gr.FindControl("chkDelFlg")).Checked)
                    {
                        if (string.IsNullOrEmpty(hdnRowId))
                        {
                            continue;
                        }
                        else
                        {
                            command.CommandText = " delete from RevEmployers where id = " + IntToDB(hdnRowId);
                            command.ExecuteScalar();
                        }
                    }
                                       
                    ClearDR(drRevEmployers);
                    //Moisture Registration

                    drRevEmployers["EmpId"] = EmpId;
                    drRevEmployers["RevEmpId"] = GetGridDDLVal(gr, "ddlEmployerName");

                    string RevEmpId = MergeRevEmp(drRevEmployers, command);
                }

            ShowMessageOK(this, "Data Inserted Successfully!");
        }

        public static void ShowMessageOK(Page page, string msg)
        {            
            string script = "alert('" + msg + "');";
            page = HttpContext.Current.CurrentHandler as Page;
            ScriptManager.RegisterStartupScript(page, page.GetType(), "clientscript3", script, true);            
        }

        #region Clear Datarow
        protected void ClearDR(DataRow dr)
        {
            for(int i = 0; i < dr.ItemArray.Length; i ++)
            {
                dr[i] = null;
            }
        }
        #endregion

        #region Insert To RevEmployerTable
        protected string MergeRevEmp(DataRow dr, SqlCommand com)
        {
            string sRet = "";

            try
            {
                string sSQL = "";
                
                if (string.IsNullOrEmpty(dr["id"].ToString()))
                {
                   sSQL = @" insert into RevEmployers(EmpId, RevEmpId) output inserted.id 
                            Values( {0}, {1} )";
                }
                else
                {
                    sSQL = @"
                                update  RevEmployers
                                            SET
                                            EmpId         = {0}
                                           ,RevEmpId      = {1}                                           
                                        where   MOISTURE_ID     = {2}
                                                    ";

                }

                com.CommandText = string.Format(sSQL
                       , dr["EmpId"]                
                       , dr["RevEmpId"]                    
                       , dr["id"]
                   );

                if (string.IsNullOrEmpty(dr["id"].ToString())) 
                {
                    SqlConnection oConn = Common.DBConnectionClass.DBConnect();
                    SqlTransaction trans = oConn.BeginTransaction(IsolationLevel.ReadCommitted);
                    SqlCommand cmd = new SqlCommand(com.CommandText, oConn, trans);
                    sRet = cmd.ExecuteNonQuery().ToString();
                    trans.Commit();

                    //sRet = com.ExecuteScalar().ToString();
                        //com.ExecuteScalar().ToString();
                }
                else
                {
                    com.ExecuteScalar();
                    sRet = dr["id"].ToString();
                }

            }
            catch
            {
                throw;
            }



            return sRet;
        }
        #endregion

        protected void ddlEmployers_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlEmployers.SelectedValue.ToString() != "0")
            {
                string sql = @" Select RevEmployers.id, RevEmpId, Name from RevEmployers 
                            left join Employees on Employees.ID = RevEmployers.RevEmpId
                            where EmpId = " + ddlEmployers.SelectedValue;
                DataTable dt = Common.DBConnectionClass.GetRecords(sql);

                //foreach (DataRow row in dt.Rows)
                //{
                //    ddlEmployerName.Items.Add(new ListItem(row["Name"].ToString(), row["RevEmpId"].ToString()));

                //}
                gvEmployers.DataSource = dt; //Common.DBConnectionClass.GetRecords(sql);
                gvEmployers.DataBind();
            }
        }

        protected void gvEmployers_RowCreated(object sender, GridViewRowEventArgs e)
        {
            switch (e.Row.RowType)
            {
                case DataControlRowType.Header:                    
                    e.Row.TableSection = TableRowSection.TableHeader;
                    break;
                case DataControlRowType.DataRow:                
                    e.Row.TableSection = TableRowSection.TableBody;
                    break;
                case DataControlRowType.Footer:                  
                    e.Row.TableSection = TableRowSection.TableFooter;
                    break;
                case DataControlRowType.Pager:                   
                    e.Row.TableSection = TableRowSection.TableHeader;
                    break;
            }
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DropDownList ddlEmpNames = (DropDownList)e.Row.FindControl("ddlEmployerName");

                string sSQL = @" Select ID, Name from Employees ";

                DataTable dt = Common.DBConnectionClass.GetRecords(sSQL);
                ddlEmpNames.Items.Add(new ListItem());                

                foreach (DataRow row in dt.Rows)
                {
                    ddlEmpNames.Items.Add(new ListItem(row["Name"].ToString(), row["ID"].ToString()));

                }
            }
        }
        
    }
}